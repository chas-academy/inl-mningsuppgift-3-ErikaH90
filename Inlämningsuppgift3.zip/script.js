// Array som håller varukorgen
const cart = [];

// Hämta HTML-element
const productNameInput = document.getElementById("productName");
const priceInput = document.getElementById("price");
const addProductBtn = document.getElementById("addProductBtn");
const cartList = document.getElementById("cartList");

// Funktion för att rendera varukorgen i listan
function renderCart() {
  // Töm listan först
  cartList.innerHTML = "";

  // Loopa igenom varukorgen och skapa listobjekt för varje produkt
  cart.forEach(item => {
    const li = document.createElement("li");
    li.textContent = `${item.productName} — Pris: ${item.price.toFixed(2)} kr — Antal: ${item.quantity}`;
    cartList.appendChild(li);
  });
}

// Funktion för att lägga till produkt i varukorgen
function addProduct() {
  const productName = productNameInput.value.trim();
  const price = parseFloat(priceInput.value);

  // Kontrollera att produktnamn inte är tomt och pris är ett giltigt tal
  if (productName === "" || isNaN(price) || price < 0) {
    alert("Var vänlig fyll i produktnamn och ett giltigt pris.");
    return;
  }

  // Kolla om produkten redan finns i varukorgen
  const existingProduct = cart.find(item => item.productName.toLowerCase() === productName.toLowerCase());

  if (existingProduct) {
    // Om produkten finns, öka quantity med 1
    existingProduct.quantity += 1;
  } else {
    // Annars, lägg till ny produkt i varukorgen
    cart.push({ productName, price, quantity: 1 });
  }

  // Rensa input-fälten
  productNameInput.value = "";
  priceInput.value = "";

  // Rendera om listan
  renderCart();
}

// Koppla knappen till funktionen
addProductBtn.addEventListener("click", addProduct);

// Visa tom varukorg initialt
renderCart();
